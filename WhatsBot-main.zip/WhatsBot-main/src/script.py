from modules.lista_de_telefones import lista_de_telefones
from modules.mensagens import  envia_mensagem_para_lista_de_tefones

telefones = lista_de_telefones()

envia_mensagem_para_lista_de_tefones(telefones)
